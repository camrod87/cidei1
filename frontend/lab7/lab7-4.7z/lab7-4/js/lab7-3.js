$(document).ready(function(){

	$('.buttonaplicar').bind('click',function(event){
		$('div').addClass('color');
		//console.log("Cambio");
		event.preventDefault();
	});
	
	
});